<template>
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
      <router-link class="navbar-brand" to="/">Household Services</router-link>
      
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav me-auto">
          <li class="nav-item">
            <router-link class="nav-link" to="/">Home</router-link>
          </li>
          
          <!-- Show these links only when user is logged in -->
          <template v-if="authStore.token">
            <li class="nav-item">
              <router-link class="nav-link" to="/dashboard">Dashboard</router-link>
            </li>
            
            <!-- Customer specific links -->
            <li v-if="authStore.user?.role === 'customer'" class="nav-item">
              <router-link class="nav-link" to="/service-requests">My Requests</router-link>
            </li>
            
            <!-- Professional specific links -->
            <li v-if="authStore.user?.role === 'professional'" class="nav-item">
              <router-link class="nav-link" to="/professional-dashboard">Professional Dashboard</router-link>
            </li>
            
            <!-- Admin specific links -->
            <li v-if="authStore.user?.role === 'admin'" class="nav-item">
              <router-link class="nav-link" to="/admin">Admin Panel</router-link>
            </li>
          </template>
        </ul>
        
        <ul class="navbar-nav">
          <!-- Show these links only when user is NOT logged in -->
          <template v-if="!authStore.token">
            <li class="nav-item">
              <router-link class="nav-link" to="/login">Login</router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/register">Register</router-link>
            </li>
          </template>
          
          <!-- Show logout when user is logged in -->
          <li v-else class="nav-item">
            <a @click="logout" class="nav-link" href="#" role="button">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</template>

<script setup lang="ts">
import { useAuthStore } from '@/stores/auth';
import { useRouter } from 'vue-router';

const authStore = useAuthStore();
const router = useRouter();

const logout = () => {
  authStore.logout();
  router.push('/login');
};
</script>