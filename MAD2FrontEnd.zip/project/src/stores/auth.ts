import { defineStore } from 'pinia';
import axios from 'axios';
import { ref } from 'vue';
import type { User } from '@/types';

export const useAuthStore = defineStore('auth', () => {
  const user = ref<User | null>(null);
  const token = ref<string | null>(null);

  const login = async (email: string, password: string) => {
    try {
      const response = await axios.post(`${import.meta.env.VITE_API_URL}/auth/login`, {
        email,
        password
      });
      
      token.value = response.data.access_token;
      // Set axios default header
      axios.defaults.headers.common['Authorization'] = `Bearer ${token.value}`;
      
      // Get user details or set from response
      user.value = {
        email,
        role: response.data.role,
        id: response.data.id,
        name: response.data.name
      };

      localStorage.setItem('token', token.value);
      localStorage.setItem('user', JSON.stringify(user.value));
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const register = async (userData: any, type: 'customer' | 'professional') => {
    try {
      const response = await axios.post(
        `${import.meta.env.VITE_API_URL}/auth/register/${type}`,
        userData
      );
      return response.data;
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  };

  const logout = () => {
    user.value = null;
    token.value = null;
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    delete axios.defaults.headers.common['Authorization'];
  };

  const checkAuth = () => {
    const savedToken = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    
    if (savedToken && savedUser) {
      token.value = savedToken;
      user.value = JSON.parse(savedUser);
      axios.defaults.headers.common['Authorization'] = `Bearer ${token.value}`;
    }
  };

  return {
    user,
    token,
    login,
    register,
    logout,
    checkAuth
  };
});