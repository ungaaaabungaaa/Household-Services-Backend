import { createRouter, createWebHistory } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import Home from '@/views/Home.vue';
import Login from '@/views/Login.vue';
import Register from '@/views/Register.vue';
import Dashboard from '@/views/Dashboard.vue';
import ServiceRequests from '@/views/ServiceRequests.vue';
import AdminPanel from '@/views/AdminPanel.vue';
import ProfessionalDashboard from '@/views/ProfessionalDashboard.vue';

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/register',
      name: 'register',
      component: Register
    },
    {
      path: '/dashboard',
      name: 'dashboard',
      component: Dashboard,
      meta: { requiresAuth: true }
    },
    {
      path: '/service-requests',
      name: 'service-requests',
      component: ServiceRequests,
      meta: { requiresAuth: true }
    },
    {
      path: '/admin',
      name: 'admin',
      component: AdminPanel,
      meta: { requiresAuth: true, requiresAdmin: true }
    },
    {
      path: '/professional-dashboard',
      name: 'professional-dashboard',
      component: ProfessionalDashboard,
      meta: { requiresAuth: true, requiresProfessional: true }
    }
  ]
});

router.beforeEach((to, from, next) => {
  const authStore = useAuthStore();
  const requiresAuth = to.matched.some(record => record.meta.requiresAuth);
  const requiresAdmin = to.matched.some(record => record.meta.requiresAdmin);
  const requiresProfessional = to.matched.some(record => record.meta.requiresProfessional);

  if (requiresAuth && !authStore.token) {
    next('/login');
  } else if (requiresAdmin && authStore.user?.role !== 'admin') {
    next('/dashboard');
  } else if (requiresProfessional && authStore.user?.role !== 'professional') {
    next('/dashboard');
  } else {
    next();
  }
});

export default router;