export interface User {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'customer' | 'professional';
}

export interface ServiceCategory {
  id: number;
  name: string;
  description: string;
}

export interface Service {
  id: number;
  name: string;
  description: string;
  category_id: number;
  category_name: string;
  base_price: number;
  required_time: number;
  average_rating?: number;
  total_reviews?: number;
}

export interface ServiceRequest {
  id: number;
  service_id: number;
  description: string;
  preferred_date: string;
  preferred_time: string;
  status: 'pending' | 'accepted' | 'completed';
  pin_code: string;
  address?: string;
  created_at: string;
}

export interface Review {
  id: number;
  service_request_id: number;
  rating: number;
  comment: string;
  aspects: {
    punctuality: number;
    professionalism: number;
    work_quality: number;
  };
  created_at: string;
}