<template>
  <div class="container">
    <h1 class="mb-4">Professional Dashboard</h1>
    
    <div class="alert alert-info" v-if="!isApproved">
      Your account is pending approval. You'll be notified once an admin approves your account.
    </div>
    
    <div v-else>
      <!-- Stats Cards -->
      <div class="row mb-4">
        <div class="col-md-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Available Requests</h5>
              <p class="display-4">{{ availableRequests.length }}</p>
            </div>
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Active Jobs</h5>
              <p class="display-4">{{ activeJobs.length }}</p>
            </div>
          </div>
        </div>
        
        <div class="col-md-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Average Rating</h5>
              <p class="display-4">
                <span class="text-warning">★</span>
                {{ averageRating.toFixed(1) }}
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <!-- Available Requests -->
      <h2 class="mb-3">Available Requests</h2>
      <div class="table-responsive mb-5">
        <table class="table">
          <thead>
            <tr>
              <th>Service</th>
              <th>Description</th>
              <th>Date & Time</th>
              <th>Location</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in availableRequests" :key="request.id">
              <td>{{ getServiceName(request.service_id) }}</td>
              <td>{{ request.description }}</td>
              <td>{{ request.preferred_date }} {{ request.preferred_time }}</td>
              <td>{{ request.pin_code }}</td>
              <td>
                <button 
                  class="btn btn-success btn-sm"
                  @click="acceptRequest(request.id)"
                  :disabled="loading"
                >
                  Accept
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <!-- Active Jobs -->
      <h2 class="mb-3">Active Jobs</h2>
      <div class="table-responsive mb-5">
        <table class="table">
          <thead>
            <tr>
              <th>Service</th>
              <th>Description</th>
              <th>Date & Time</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="job in activeJobs" :key="job.id">
              <td>{{ getServiceName(job.service_id) }}</td>
              <td>{{ job.description }}</td>
              <td>{{ job.preferred_date }} {{ job.preferred_time }}</td>
              <td>
                <span :class="getStatusBadgeClass(job.status)">
                  {{ job.status }}
                </span>
              </td>
              <td>
                <button 
                  v-if="job.status === 'accepted'"
                  class="btn btn-primary btn-sm"
                  @click="showCompleteJobModal(job)"
                >
                  Complete
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      
      <!-- Reviews -->
      <h2 class="mb-3">Recent Reviews</h2>
      <div class="row">
        <div v-for="review in recentReviews" :key="review.id" class="col-md-4 mb-4">
          <div class="card">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="rating">
                  <span class="text-warning">★</span>
                  {{ review.rating }}
                </div>
                <small class="text-muted">
                  {{ new Date(review.created_at).toLocaleDateString() }}
                </small>
              </div>
              <p class="card-text">{{ review.comment }}</p>
              <div class="small text-muted">
                <div>Punctuality: {{ review.aspects.punctuality }}/5</div>
                <div>Professionalism: {{ review.aspects.professionalism }}/5</div>
                <div>Work Quality: {{ review.aspects.work_quality }}/5</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Complete Job Modal -->
    <div v-if="showCompleteModal" class="modal d-block" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Complete Job</h5>
            <button type="button" class="btn-close" @click="showCompleteModal = false"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="completeJob">
              <div class="mb-3">
                <label class="form-label">Notes</label>
                <textarea
                  v-model="completionNotes.notes"
                  class="form-control"
                  rows="3"
                  required
                ></textarea>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Duration (minutes)</label>
                <input
                  v-model.number="completionNotes.duration"
                  type="number"
                  class="form-control"
                  required
                />
              </div>
              
              <button type="submit" class="btn btn-primary" :disabled="loading">
                {{ loading ? 'Completing...' : 'Complete Job' }}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue';
import axios from 'axios';
import { useToast } from 'vue-toastification';
import type { ServiceRequest, Service, Review } from '@/types';

const toast = useToast();
const loading = ref(false);
const isApproved = ref(true);
const showCompleteModal = ref(false);

const availableRequests = ref<ServiceRequest[]>([]);
const activeJobs = ref<ServiceRequest[]>([]);
const recentReviews = ref<Review[]>([]);
const services = ref<Service[]>([]);
const averageRating = ref(0);
const selectedJob = ref<ServiceRequest | null>(null);

const completionNotes = reactive({
  notes: '',
  duration: 0
});

const getStatusBadgeClass = (status: string) => {
  const classes = {
    pending: 'badge bg-warning',
    accepted: 'badge bg-info',
    completed: 'badge bg-success'
  };
  return classes[status as keyof typeof classes] || 'badge bg-secondary';
};

const getServiceName = (serviceId: number) => {
  const service = services.value.find(s => s.id === serviceId);
  return service ? service.name : 'Unknown Service';
};

const fetchData = async () => {
  try {
    const [requestsResponse, reviewsResponse, servicesResponse] = await Promise.all([
      axios.get(`${import.meta.env.VITE_API_URL}/professional/requests`),
      axios.get(`${import.meta.env.VITE_API_URL}/professional/reviews`),
      axios.get(`${import.meta.env.VITE_API_URL}/services`)
    ]);
    
    availableRequests.value = requestsResponse.data.filter(
      (req: ServiceRequest) => req.status === 'pending'
    );
    activeJobs.value = requestsResponse.data.filter(
      (req: ServiceRequest) => req.status === 'accepted'
    );
    recentReviews.value = reviewsResponse.data;
    services.value = servicesResponse.data;
    
    // Calculate average rating
    if (recentReviews.value.length > 0) {
      averageRating.value = recentReviews.value.reduce(
        (acc, review) => acc + review.rating, 0
      ) / recentReviews.value.length;
    }
  } catch (error: any) {
    if (error.response?.status === 403) {
      isApproved.value = false;
    } else {
      toast.error('Failed to load dashboard data');
    }
  }
};

const acceptRequest = async (requestId: number) => {
  loading.value = true;
  try {
    await axios.post(`${import.meta.env.VITE_API_URL}/professional/requests/${requestId}/accept`);
    toast.success('Request accepted successfully');
    await fetchData();
  } catch (error) {
    toast.error('Failed to accept request');
  } finally {
    loading.value = false;
  }
};

const showCompleteJobModal = (job: ServiceRequest) => {
  selectedJob.value = job;
  showCompleteModal.value = true;
};

const completeJob = async () => {
  if (!selectedJob.value) return;
  
  loading.value = true;
  try {
    await axios.post(
      `${import.meta.env.VITE_API_URL}/professional/requests/${selectedJob.value.id}/complete`,
      completionNotes
    );
    toast.success('Job completed successfully');
    showCompleteModal.value = false;
    await fetchData();
  } catch (error) {
    toast.error('Failed to complete job');
  } finally {
    loading.value = false;
  }
};

onMounted(fetchData);
</script>

<style scoped>
.modal {
  background-color: rgba(0, 0, 0, 0.5);
}

.rating {
  font-size: 1.2rem;
}
</style>