<template>
  <div class="container">
    <div class="row mb-4">
      <div class="col-12 text-center">
        <h1 class="display-4">Welcome to Household Services</h1>
        <p class="lead">Find trusted professionals for all your household needs</p>
      </div>
    </div>

    <!-- Search Section -->
    <div class="row mb-5">
      <div class="col-md-8 mx-auto">
        <div class="card">
          <div class="card-body">
            <div class="input-group mb-3">
              <input
                v-model="searchQuery"
                type="text"
                class="form-control"
                placeholder="Search for services..."
                @input="handleSearch"
              />
              <select v-model="selectedCategory" class="form-select" style="max-width: 200px">
                <option value="">All Categories</option>
                <option v-for="category in categories" :key="category.id" :value="category.id">
                  {{ category.name }}
                </option>
              </select>
              <button class="btn btn-primary" @click="handleSearch">Search</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Services List -->
    <div class="row">
      <div v-for="service in services" :key="service.id" class="col-md-4 mb-4">
        <div class="card h-100">
          <div class="card-body">
            <h5 class="card-title">{{ service.name }}</h5>
            <h6 class="card-subtitle mb-2 text-muted">{{ service.category_name }}</h6>
            <p class="card-text">{{ service.description }}</p>
            <div class="d-flex justify-content-between align-items-center">
              <span class="text-primary fw-bold">${{ service.base_price }}</span>
              <span class="text-muted">{{ service.required_time }} mins</span>
            </div>
            <div v-if="service.average_rating" class="mt-2">
              <span class="text-warning">★</span>
              {{ service.average_rating.toFixed(1) }}
              ({{ service.total_reviews }} reviews)
            </div>
          </div>
          <div class="card-footer">
            <button
              @click="bookService(service)"
              class="btn btn-primary w-100"
              :disabled="!authStore.token || authStore.user?.role !== 'customer'"
            >
              Book Now
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import axios from 'axios';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import { useToast } from 'vue-toastification';
import type { Service, ServiceCategory } from '@/types';

const router = useRouter();
const authStore = useAuthStore();
const toast = useToast();

const services = ref<Service[]>([]);
const categories = ref<ServiceCategory[]>([]);
const searchQuery = ref('');
const selectedCategory = ref('');

const fetchCategories = async () => {
  try {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/services/categories`);
    categories.value = response.data;
  } catch (error) {
    console.error('Error fetching categories:', error);
  }
};

const handleSearch = async () => {
  try {
    const params = new URLSearchParams();
    if (searchQuery.value) params.append('q', searchQuery.value);
    if (selectedCategory.value) params.append('category_id', selectedCategory.value);

    const response = await axios.get(`${import.meta.env.VITE_API_URL}/services/search?${params}`);
    services.value = response.data;
  } catch (error) {
    console.error('Error searching services:', error);
    toast.error('Failed to search services');
  }
};

const bookService = (service: Service) => {
  if (!authStore.token) {
    toast.info('Please login to book a service');
    router.push('/login');
    return;
  }
  
  if (authStore.user?.role !== 'customer') {
    toast.info('Only customers can book services');
    return;
  }
  
  router.push({
    name: 'service-requests',
    query: { service_id: service.id }
  });
};

onMounted(async () => {
  await fetchCategories();
  await handleSearch();
});
</script>