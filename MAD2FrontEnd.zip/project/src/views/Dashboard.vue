<template>
  <div class="container">
    <h1 class="mb-4">Dashboard</h1>
    
    <!-- Customer Dashboard -->
    <div v-if="authStore.user?.role === 'customer'">
      <div class="row">
        <div class="col-md-4 mb-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Active Requests</h5>
              <p class="display-4">{{ activeRequests.length }}</p>
              <router-link to="/service-requests" class="btn btn-primary">View Requests</router-link>
            </div>
          </div>
        </div>
      </div>
      
      <h2 class="mb-3">Recent Service Requests</h2>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Service</th>
              <th>Date</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="request in recentRequests" :key="request.id">
              <td>{{ request.service_id }}</td>
              <td>{{ request.preferred_date }} {{ request.preferred_time }}</td>
              <td>
                <span :class="getStatusBadgeClass(request.status)">
                  {{ request.status }}
                </span>
              </td>
              <td>
                <router-link 
                  :to="{ name: 'service-requests', query: { id: request.id }}"
                  class="btn btn-sm btn-primary"
                >
                  View Details
                </router-link>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    
    <!-- Professional Dashboard -->
    <div v-else-if="authStore.user?.role === 'professional'">
      <div class="alert alert-info" v-if="!isApproved">
        Your account is pending approval. You'll be notified once an admin approves your account.
      </div>
      
      <div v-else>
        <div class="row">
          <div class="col-md-4 mb-4">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Available Requests</h5>
                <p class="display-4">{{ availableRequests.length }}</p>
                <router-link to="/professional-dashboard" class="btn btn-primary">View Requests</router-link>
              </div>
            </div>
          </div>
          
          <div class="col-md-4 mb-4">
            <div class="card">
              <div class="card-body">
                <h5 class="card-title">Average Rating</h5>
                <p class="display-4">
                  <span class="text-warning">★</span>
                  {{ averageRating.toFixed(1) }}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- Admin Dashboard -->
    <div v-else-if="authStore.user?.role === 'admin'">
      <div class="row">
        <div class="col-md-4 mb-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Pending Professionals</h5>
              <p class="display-4">{{ pendingProfessionals.length }}</p>
              <router-link to="/admin" class="btn btn-primary">View Professionals</router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue';
import axios from 'axios';
import { useAuthStore } from '@/stores/auth';
import { useToast } from 'vue-toastification';
import type { ServiceRequest } from '@/types';

const authStore = useAuthStore();
const toast = useToast();

const activeRequests = ref<ServiceRequest[]>([]);
const recentRequests = ref<ServiceRequest[]>([]);
const availableRequests = ref<ServiceRequest[]>([]);
const pendingProfessionals = ref([]);
const isApproved = ref(true);
const averageRating = ref(0);

const getStatusBadgeClass = (status: string) => {
  const classes = {
    pending: 'badge bg-warning',
    accepted: 'badge bg-info',
    completed: 'badge bg-success'
  };
  return classes[status as keyof typeof classes] || 'badge bg-secondary';
};

const fetchDashboardData = async () => {
  try {
    if (authStore.user?.role === 'customer') {
      const response = await axios.get(`${import.meta.env.VITE_API_URL}/customer/service-requests`);
      activeRequests.value = response.data.filter((req: ServiceRequest) => 
        req.status === 'pending' || req.status === 'accepted'
      );
      recentRequests.value = response.data.slice(0, 5);
    } else if (authStore.user?.role === 'professional') {
      const [requestsResponse, reviewsResponse] = await Promise.all([
        axios.get(`${import.meta.env.VITE_API_URL}/professional/requests`),
        axios.get(`${import.meta.env.VITE_API_URL}/professional/reviews`)
      ]);
      availableRequests.value = requestsResponse.data;
      
      // Calculate average rating
      const reviews = reviewsResponse.data;
      if (reviews.length > 0) {
        averageRating.value = reviews.reduce((acc: number, review: any) => 
          acc + review.rating, 0) / reviews.length;
      }
    } else if (authStore.user?.role === 'admin') {
      const response = await axios.get(`${import.meta.env.VITE_API_URL}/admin/professionals/pending`);
      pendingProfessionals.value = response.data;
    }
  } catch (error: any) {
    if (error.response?.status === 403) {
      isApproved.value = false;
    }
    toast.error('Failed to load dashboard data');
  }
};

onMounted(fetchDashboardData);
</script>