<template>
  <div class="container">
    <h1 class="mb-4">Admin Panel</h1>
    
    <ul class="nav nav-tabs mb-4">
      <li class="nav-item">
        <a 
          class="nav-link" 
          :class="{ active: activeTab === 'professionals' }"
          @click="activeTab = 'professionals'"
          href="#"
        >
          Professionals
        </a>
      </li>
      <li class="nav-item">
        <a 
          class="nav-link" 
          :class="{ active: activeTab === 'services' }"
          @click="activeTab = 'services'"
          href="#"
        >
          Services
        </a>
      </li>
      <li class="nav-item">
        <a 
          class="nav-link" 
          :class="{ active: activeTab === 'categories' }"
          @click="activeTab = 'categories'"
          href="#"
        >
          Categories
        </a>
      </li>
    </ul>
    
    <!-- Professionals Tab -->
    <div v-if="activeTab === 'professionals'">
      <h2>Pending Professionals</h2>
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Service Type</th>
              <th>Experience</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="professional in pendingProfessionals" :key="professional.id">
              <td>{{ professional.name }}</td>
              <td>{{ professional.email }}</td>
              <td>{{ professional.service_type }}</td>
              <td>{{ professional.experience }} years</td>
              <td>
                <button 
                  class="btn btn-success btn-sm"
                  @click="approveProfessional(professional.id)"
                  :disabled="loading"
                >
                  Approve
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    
    <!-- Services Tab -->
    <div v-if="activeTab === 'services'">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Services</h2>
        <button class="btn btn-primary" @click="showNewServiceModal = true">
          Add Service
        </button>
      </div>
      
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Category</th>
              <th>Base Price</th>
              <th>Required Time</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="service in services" :key="service.id">
              <td>{{ service.name }}</td>
              <td>{{ service.category_name }}</td>
              <td>${{ service.base_price }}</td>
              <td>{{ service.required_time }} mins</td>
              <td>
                <button class="btn btn-info btn-sm">Edit</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    
    <!-- Categories Tab -->
    <div v-if="activeTab === 'categories'">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Service Categories</h2>
        <button class="btn btn-primary" @click="showNewCategoryModal = true">
          Add Category
        </button>
      </div>
      
      <div class="table-responsive">
        <table class="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Description</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="category in categories" :key="category.id">
              <td>{{ category.name }}</td>
              <td>{{ category.description }}</td>
              <td>
                <button class="btn btn-info btn-sm">Edit</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    
    <!-- New Service Modal -->
    <div v-if="showNewServiceModal" class="modal d-block" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Add New Service</h5>
            <button type="button" class="btn-close" @click="showNewServiceModal = false"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="submitNewService">
              <div class="mb-3">
                <label class="form-label">Name</label>
                <input v-model="newService.name" type="text" class="form-control" required />
              </div>
              
              <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea v-model="newService.description" class="form-control" rows="3" required></textarea>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Category</label>
                <select v-model="newService.category_id" class="form-select" required>
                  <option value="">Select a category</option>
                  <option v-for="category in categories" :key="category.id" :value="category.id">
                    {{ category.name }}
                  </option>
                </select>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Base Price ($)</label>
                <input v-model.number="newService.base_price" type="number" class="form-control" required />
              </div>
              
              <div class="mb-3">
                <label class="form-label">Required Time (minutes)</label>
                <input v-model.number="newService.required_time" type="number" class="form-control" required />
              </div>
              
              <button type="submit" class="btn btn-primary" :disabled="loading">
                {{ loading ? 'Adding...' : 'Add Service' }}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
    
    <!-- New Category Modal -->
    <div v-if="showNewCategoryModal" class="modal d-block" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Add New Category</h5>
            <button type="button" class="btn-close" @click="showNewCategoryModal = false"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="submitNewCategory">
              <div class="mb-3">
                <label class="form-label">Name</label>
                <input v-model="newCategory.name" type="text" class="form-control" required />
              </div>
              
              <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea v-model="newCategory.description" class="form-control" rows="3" required></textarea>
              </div>
              
              <button type="submit" class="btn btn-primary" :disabled="loading">
                {{ loading ? 'Adding...' : 'Add Category' }}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue';
import axios from 'axios';
import { useToast } from 'vue-toastification';
import type { Service, ServiceCategory } from '@/types';

const toast = useToast();
const loading = ref(false);
const activeTab = ref('professionals');
const showNewServiceModal = ref(false);
const showNewCategoryModal = ref(false);

const pendingProfessionals = ref([]);
const services = ref<Service[]>([]);
const categories = ref<ServiceCategory[]>([]);

const newService = reactive({
  name: '',
  description: '',
  category_id: '',
  base_price: 0,
  required_time: 0
});

const newCategory = reactive({
  name: '',
  description: ''
});

const fetchPendingProfessionals = async () => {
  try {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/admin/professionals/pending`);
    pendingProfessionals.value = response.data;
  } catch (error) {
    toast.error('Failed to load pending professionals');
  }
};

const fetchServices = async () => {
  try {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/services`);
    services.value = response.data;
  } catch (error) {
    toast.error('Failed to load services');
  }
};

const fetchCategories = async () => {
  try {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/services/categories`);
    categories.value = response.data;
  } catch (error) {
    toast.error('Failed to load categories');
  }
};

const approveProfessional = async (id: number) => {
  loading.value = true;
  try {
    await axios.post(`${import.meta.env.VITE_API_URL}/admin/professionals/${id}/approve`);
    toast.success('Professional approved successfully');
    await fetchPendingProfessionals();
  } catch (error) {
    toast.error('Failed to approve professional');
  } finally {
    loading.value = false;
  }
};

const submitNewService = async () => {
  loading.value = true;
  try {
    await axios.post(`${import.meta.env.VITE_API_URL}/admin/services`, newService);
    toast.success('Service added successfully');
    showNewServiceModal.value = false;
    await fetchServices();
  } catch (error) {
    toast.error('Failed to add service');
  } finally {
    loading.value = false;
  }
};

const submitNewCategory = async () => {
  loading.value = true;
  try {
    await axios.post(`${import.meta.env.VITE_API_URL}/admin/services/categories`, newCategory);
    toast.success('Category added successfully');
    showNewCategoryModal.value = false;
    await fetchCategories();
  } catch (error) {
    toast.error('Failed to add category');
  } finally {
    loading.value = false;
  }
};

onMounted(async () => {
  await Promise.all([
    fetchPendingProfessionals(),
    fetchServices(),
    fetchCategories()
  ]);
});
</script>

<style scoped>
.modal {
  background-color: rgba(0, 0, 0, 0.5);
}

.nav-link {
  cursor: pointer;
}
</style>