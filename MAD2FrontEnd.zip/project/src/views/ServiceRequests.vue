<template>
  <div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h1>Service Requests</h1>
      <button class="btn btn-primary" @click="showNewRequestModal = true">
        New Request
      </button>
    </div>

    <!-- Service Requests List -->
    <div class="table-responsive">
      <table class="table">
        <thead>
          <tr>
            <th>Service</th>
            <th>Description</th>
            <th>Date & Time</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="request in requests" :key="request.id">
            <td>{{ getServiceName(request.service_id) }}</td>
            <td>{{ request.description }}</td>
            <td>{{ request.preferred_date }} {{ request.preferred_time }}</td>
            <td>
              <span :class="getStatusBadgeClass(request.status)">
                {{ request.status }}
              </span>
            </td>
            <td>
              <button 
                v-if="request.status === 'completed'"
                class="btn btn-sm btn-primary me-2"
                @click="openReviewModal(request)"
              >
                Review
              </button>
              <button
                class="btn btn-sm btn-info"
                @click="showRequestDetails(request)"
              >
                Details
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- New Request Modal -->
    <div v-if="showNewRequestModal" class="modal d-block" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">New Service Request</h5>
            <button type="button" class="btn-close" @click="showNewRequestModal = false"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="submitRequest">
              <div class="mb-3">
                <label class="form-label">Service</label>
                <select v-model="newRequest.service_id" class="form-select" required>
                  <option value="">Select a service</option>
                  <option v-for="service in services" :key="service.id" :value="service.id">
                    {{ service.name }}
                  </option>
                </select>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea
                  v-model="newRequest.description"
                  class="form-control"
                  rows="3"
                  required
                ></textarea>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Preferred Date</label>
                <input
                  v-model="newRequest.preferred_date"
                  type="date"
                  class="form-control"
                  required
                />
              </div>
              
              <div class="mb-3">
                <label class="form-label">Preferred Time</label>
                <input
                  v-model="newRequest.preferred_time"
                  type="time"
                  class="form-control"
                  required
                />
              </div>
              
              <div class="mb-3">
                <label class="form-label">Address</label>
                <textarea
                  v-model="newRequest.address"
                  class="form-control"
                  rows="2"
                  required
                ></textarea>
              </div>
              
              <div class="mb-3">
                <label class="form-label">PIN Code</label>
                <input
                  v-model="newRequest.pin_code"
                  type="text"
                  class="form-control"
                  required
                />
              </div>
              
              <button type="submit" class="btn btn-primary" :disabled="loading">
                {{ loading ? 'Submitting...' : 'Submit Request' }}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Review Modal -->
    <div v-if="showReviewModal" class="modal d-block" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Submit Review</h5>
            <button type="button" class="btn-close" @click="showReviewModal = false"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="submitReview">
              <div class="mb-3">
                <label class="form-label">Overall Rating</label>
                <div class="rating">
                  <template v-for="n in 5" :key="n">
                    <span
                      class="star"
                      :class="{ active: review.rating >= n }"
                      @click="review.rating = n"
                    >★</span>
                  </template>
                </div>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Punctuality</label>
                <input
                  v-model.number="review.aspects.punctuality"
                  type="range"
                  class="form-range"
                  min="1"
                  max="5"
                />
                <span>{{ review.aspects.punctuality }}</span>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Professionalism</label>
                <input
                  v-model.number="review.aspects.professionalism"
                  type="range"
                  class="form-range"
                  min="1"
                  max="5"
                />
                <span>{{ review.aspects.professionalism }}</span>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Work Quality</label>
                <input
                  v-model.number="review.aspects.work_quality"
                  type="range"
                  class="form-range"
                  min="1"
                  max="5"
                />
                <span>{{ review.aspects.work_quality }}</span>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Comment</label>
                <textarea
                  v-model="review.comment"
                  class="form-control"
                  rows="3"
                  required
                ></textarea>
              </div>
              
              <button type="submit" class="btn btn-primary" :disabled="loading">
                {{ loading ? 'Submitting...' : 'Submit Review' }}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, reactive } from 'vue';
import axios from 'axios';
import { useToast } from 'vue-toastification';
import type { ServiceRequest, Service } from '@/types';

const toast = useToast();
const loading = ref(false);
const requests = ref<ServiceRequest[]>([]);
const services = ref<Service[]>([]);
const showNewRequestModal = ref(false);
const showReviewModal = ref(false);
const selectedRequest = ref<ServiceRequest | null>(null);

const newRequest = reactive({
  service_id: '',
  description: '',
  preferred_date: '',
  preferred_time: '',
  address: '',
  pin_code: ''
});

const review = reactive({
  service_request_id: 0,
  rating: 0,
  comment: '',
  aspects: {
    punctuality: 3,
    professionalism: 3,
    work_quality: 3
  }
});

const getStatusBadgeClass = (status: string) => {
  const classes = {
    pending: 'badge bg-warning',
    accepted: 'badge bg-info',
    completed: 'badge bg-success'
  };
  return classes[status as keyof typeof classes] || 'badge bg-secondary';
};

const getServiceName = (serviceId: number) => {
  const service = services.value.find(s => s.id === serviceId);
  return service ? service.name : 'Unknown Service';
};

const fetchRequests = async () => {
  try {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/customer/service-requests`);
    requests.value = response.data;
  } catch (error) {
    toast.error('Failed to load service requests');
  }
};

const fetchServices = async () => {
  try {
    const response = await axios.get(`${import.meta.env.VITE_API_URL}/services`);
    services.value = response.data;
  } catch (error) {
    toast.error('Failed to load services');
  }
};

const submitRequest = async () => {
  loading.value = true;
  try {
    await axios.post(`${import.meta.env.VITE_API_URL}/customer/service-request`, newRequest);
    toast.success('Service request submitted successfully');
    showNewRequestModal.value = false;
    await fetchRequests();
  } catch (error) {
    toast.error('Failed to submit service request');
  } finally {
    loading.value = false;
  }
};

const openReviewModal = (request: ServiceRequest) => {
  selectedRequest.value = request;
  review.service_request_id = request.id;
  showReviewModal.value = true;
};

const submitReview = async () => {
  loading.value = true;
  try {
    await axios.post(`${import.meta.env.VITE_API_URL}/customer/reviews`, review);
    toast.success('Review submitted successfully');
    showReviewModal.value = false;
    await fetchRequests();
  } catch (error) {
    toast.error('Failed to submit review');
  } finally {
    loading.value = false;
  }
};

const showRequestDetails = (request: ServiceRequest) => {
  selectedRequest.value = request;
  // Implement details view logic
};

onMounted(async () => {
  await Promise.all([fetchRequests(), fetchServices()]);
});
</script>

<style scoped>
.modal {
  background-color: rgba(0, 0, 0, 0.5);
}

.rating {
  display: flex;
  gap: 5px;
}

.star {
  cursor: pointer;
  font-size: 24px;
  color: #ccc;
}

.star.active {
  color: #ffd700;
}
</style>