<template>
  <div class="row justify-content-center">
    <div class="col-md-6">
      <div class="card">
        <div class="card-body">
          <h2 class="card-title text-center mb-4">Register</h2>
          
          <div class="mb-4">
            <div class="btn-group w-100">
              <button 
                @click="userType = 'customer'"
                :class="['btn', userType === 'customer' ? 'btn-primary' : 'btn-outline-primary']"
              >
                Customer
              </button>
              <button 
                @click="userType = 'professional'"
                :class="['btn', userType === 'professional' ? 'btn-primary' : 'btn-outline-primary']"
              >
                Professional
              </button>
            </div>
          </div>
          
          <form @submit.prevent="handleSubmit">
            <div class="mb-3">
              <label for="name" class="form-label">Name</label>
              <input
                v-model="formData.name"
                type="text"
                class="form-control"
                id="name"
                required
              />
            </div>
            
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
              <input
                v-model="formData.email"
                type="email"
                class="form-control"
                id="email"
                required
              />
            </div>
            
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
              <input
                v-model="formData.password"
                type="password"
                class="form-control"
                id="password"
                required
              />
            </div>
            
            <!-- Customer specific fields -->
            <div v-if="userType === 'customer'" class="mb-3">
              <label for="pin_code" class="form-label">PIN Code</label>
              <input
                v-model="formData.pin_code"
                type="text"
                class="form-control"
                id="pin_code"
                required
              />
            </div>
            
            <!-- Professional specific fields -->
            <template v-if="userType === 'professional'">
              <div class="mb-3">
                <label for="service_type" class="form-label">Service Type</label>
                <input
                  v-model="formData.service_type"
                  type="text"
                  class="form-control"
                  id="service_type"
                  required
                />
              </div>
              
              <div class="mb-3">
                <label for="experience" class="form-label">Years of Experience</label>
                <input
                  v-model.number="formData.experience"
                  type="number"
                  class="form-control"
                  id="experience"
                  min="0"
                  required
                />
              </div>
              
              <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea
                  v-model="formData.description"
                  class="form-control"
                  id="description"
                  rows="3"
                  required
                ></textarea>
              </div>
            </template>
            
            <button type="submit" class="btn btn-primary w-100" :disabled="loading">
              {{ loading ? 'Registering...' : 'Register' }}
            </button>
          </form>
          
          <div class="mt-3 text-center">
            <router-link to="/login">Already have an account? Login here</router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue';
import { useRouter } from 'vue-router';
import { useAuthStore } from '@/stores/auth';
import { useToast } from 'vue-toastification';

const router = useRouter();
const authStore = useAuthStore();
const toast = useToast();

const userType = ref<'customer' | 'professional'>('customer');
const loading = ref(false);

const formData = reactive({
  name: '',
  email: '',
  password: '',
  pin_code: '',
  service_type: '',
  experience: 0,
  description: ''
});

const handleSubmit = async () => {
  loading.value = true;
  try {
    await authStore.register(formData, userType.value);
    toast.success('Registration successful! Please login.');
    router.push('/login');
  } catch (error: any) {
    toast.error(error.response?.data?.message || 'Registration failed');
  } finally {
    loading.value = false;
  }
};
</script>